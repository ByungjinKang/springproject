package org.zerock.example.mapper;

import org.apache.ibatis.annotations.Select;

public interface TimeMapper {

    @Select("SELECT example_date FROM example_board where example_number = 1")
    public String getTime();

    public String getTitle();
}
